package simulator;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;

public class Graph {
    public static void main(String[] args) {
        String filename = "C:/Users/Pedro/Desktop/Projecto_3_IA_ALUNOS/lib/detector.fcl";
    FIS fis = FIS.load(filename, true);

    if (fis == null) {
        System.err.println("Can't load file: '" + filename + "'");
        System.exit(1);
    }
    
    // Get default function block
    FunctionBlock fb = fis.getFunctionBlock(null);

    // Show 
    JFuzzyChart.get().chart(fb);

    // Set inputs
    fb.setVariable("mushroom", 6);
    fb.setVariable("sensor_angle", 180);
    fb.setVariable("velocity", 2);
    fb.setVariable("distance", 5);

    // Evaluate
    fb.evaluate();

    // Show output variable's chart
    fb.getVariable("action").defuzzify();
    
    // Print ruleSet
    System.out.println(fb);
    System.out.println("Action: " + fb.getVariable("action").getValue());
    }

}