package simulator;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class main {


	public static void main(String[] args) throws Exception{
		DataSource source = new DataSource("mushroom.arff");

		//Obtain FCL File
		String filename = "C:\\Users\\sfdio\\eclipse-workspace\\Projecto_3_IA_ALUNOS\\lib\\Detector.fcl";

		//Fuzzify
		FIS fis = FIS.load(filename, true);

		//Create function blocks for decision making
		J48 cls = new J48();
		FunctionBlock fb = fis.getFunctionBlock(null);

		Instances instances = source.getDataSet();
		instances.setClassIndex(instances.numAttributes() - 1);
		cls.buildClassifier(instances);


		Simulator game = new Simulator();
		game.setRobotSpeed(game.getRobotSpeed()*2);

		while(true){
			NewInstances ni = new NewInstances(source.getDataSet());

			fb.setVariable("distanceL", game.getDistanceL());
			fb.setVariable("distanceC", game.getDistanceC());
			fb.setVariable("distanceR", game.getDistanceR());
			fb.evaluate();
			fb.getVariable("angle").defuzzify();

			game.setRobotAngle(fb.getVariable("angle").getValue());

			if(game.getMushroomAttributes()!=null) {
				ni.addInstance(game.getMushroomAttributes());
				Instances ins = ni.getDataset();
				ins.setClassIndex(source.getDataSet().numAttributes()-1);
				double b = cls.classifyInstance(ins.instance(0));


				fb.setVariable("mushroom",b*10);
				fb.evaluate();

				if (game.getDistanceC() < 1) {

					if(fb.getVariable("action").defuzzify() <= 1.8){

						game.setAction(Action.DESTROY);

					} else if(fb.getVariable("action").defuzzify() >= 2.2){

						game.setAction(Action.PICK_UP);

					}else{

						game.setAction(Action.NO_ACTION);

					}
				}
				else
				{
					game.setAction(Action.NO_ACTION);
				}

			}else {
				game.setAction(Action.NO_ACTION);
			}






			game.step();
		}


	}

}